from animals import Cat

garfield = Cat('Garfield', '1/1/1978', 'Orange', 'Tabby')

garfield.printit()

print(garfield)
